
import os
import socket
import sqlite3
import time
from datetime import datetime, timezone

import psutil
import requests
from flask import Flask, jsonify, render_template_string, request

app = Flask(__name__)

DB_PATH = "/data/monitor.db"
DOCKER_API = os.getenv("DOCKER_API", "http://docker-proxy:2375")
START_TIME = time.time()

# Read host-level information through read-only mounted filesystems.
psutil.PROCFS_PATH = "/host/proc"
psutil.SYSFS_PATH = "/host/sys"

def init_db():
    os.makedirs("/data", exist_ok=True)
    with sqlite3.connect(DB_PATH) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS visits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT,
                path TEXT,
                visited_at TEXT
            )
        """)

def get_db():
    return sqlite3.connect(DB_PATH)

def host_ip():
    try:
        return socket.gethostbyname("host.docker.internal")
    except Exception:
        return "Unavailable"

def container_ip():
    try:
        return socket.gethostbyname(socket.gethostname())
    except Exception:
        return "Unavailable"

def docker_get(path, timeout=3):
    try:
        r = requests.get(
            DOCKER_API + path,
            timeout=timeout
        )
        r.raise_for_status()
        return r.json()
    except Exception:
        return None

def get_container_stats(container_id):
    stats = docker_get(
        f"/containers/{container_id}/stats?stream=false"
    )
    if not stats:
        return {}

    cpu = stats.get("cpu_stats", {})
    previous = stats.get("precpu_stats", {})

    cpu_delta = (
        cpu.get("cpu_usage", {}).get("total_usage", 0)
        - previous.get("cpu_usage", {}).get("total_usage", 0)
    )

    system_delta = (
        cpu.get("system_cpu_usage", 0)
        - previous.get("system_cpu_usage", 0)
    )

    cpu_count = cpu.get("online_cpus") or len(
        cpu.get("cpu_usage", {}).get("percpu_usage", []) or [1]
    )

    cpu_percent = 0
    if cpu_delta > 0 and system_delta > 0:
        cpu_percent = (cpu_delta / system_delta) * cpu_count * 100

    memory = stats.get("memory_stats", {})
    usage = memory.get("usage", 0)
    limit = memory.get("limit", 0)

    networks = stats.get("networks", {})
    rx = sum(v.get("rx_bytes", 0) for v in networks.values())
    tx = sum(v.get("tx_bytes", 0) for v in networks.values())

    return {
        "cpu_percent": round(cpu_percent, 2),
        "memory_usage_mb": round(usage / 1048576, 2),
        "memory_limit_mb": round(limit / 1048576, 2),
        "memory_percent": round(usage / limit * 100, 2) if limit else 0,
        "network_rx_mb": round(rx / 1048576, 2),
        "network_tx_mb": round(tx / 1048576, 2)
    }

def get_containers():
    containers = docker_get("/containers/json?all=1")
    if containers is None:
        return []

    result = []

    for c in containers:
        cid = c["Id"]
        running = c["State"] == "running"

        ports = c.get("Ports", [])
        networks = c.get("NetworkSettings", {}).get("Networks", {})

        ips = [
            n.get("IPAddress")
            for n in networks.values()
            if n.get("IPAddress")
        ]

        stats = get_container_stats(cid) if running else {}

        result.append({
            "id": cid[:12],
            "name": ",".join(c.get("Names", [])),
            "image": c.get("Image"),
            "state": c.get("State"),
            "status": c.get("Status"),
            "ip": ", ".join(ips) or "N/A",
            "ports": ports,
            "stats": stats
        })

    return result

def get_host():
    try:
        hostname = open("/host/etc/hostname").read().strip()
    except Exception:
        hostname = socket.gethostname()

    try:
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("/host/root")
        cpu = psutil.cpu_percent(interval=0.1)
        load = os.getloadavg()
        uptime = time.time() - psutil.boot_time()

        return {
            "hostname": hostname,
            "ip": host_ip(),
            "cpu_percent": cpu,
            "cpu_count": psutil.cpu_count(),
            "memory_total_gb": round(mem.total / 1073741824, 2),
            "memory_used_gb": round(mem.used / 1073741824, 2),
            "memory_percent": mem.percent,
            "disk_total_gb": round(disk.total / 1073741824, 2),
            "disk_used_gb": round(disk.used / 1073741824, 2),
            "disk_percent": disk.percent,
            "load_average": list(load),
            "uptime_hours": round(uptime / 3600, 2)
        }
    except Exception as e:
        return {"error": str(e)}

def get_docker_info():
    info = docker_get("/info")
    if not info:
        return {"status": "Unavailable"}

    return {
        "status": "Connected",
        "version": info.get("ServerVersion"),
        "containers": info.get("Containers"),
        "running": info.get("ContainersRunning"),
        "paused": info.get("ContainersPaused"),
        "stopped": info.get("ContainersStopped"),
        "images": info.get("Images"),
        "operating_system": info.get("OperatingSystem"),
        "architecture": info.get("Architecture"),
        "driver": info.get("Driver")
    }

def nginx_status():
    try:
        r = requests.get(
            "http://127.0.0.1:8081/nginx_status",
            timeout=2
        )
        return {
            "status": "Running" if r.ok else "Error",
            "details": r.text.strip()
        }
    except Exception:
        return {"status": "Unavailable", "details": ""}

def visitor_data():
    with get_db() as db:
        total = db.execute(
            "SELECT COUNT(*) FROM visits"
        ).fetchone()[0]

        unique = db.execute(
            "SELECT COUNT(DISTINCT ip) FROM visits"
        ).fetchone()[0]

        recent = db.execute("""
            SELECT ip, path, visited_at
            FROM visits ORDER BY id DESC LIMIT 10
        """).fetchall()

    return {
        "total_hits": total,
        "unique_visitors": unique,
        "recent": [
            {"ip": x[0], "path": x[1], "time": x[2]}
            for x in recent
        ]
    }

@app.before_request
def track_visit():
    if request.path == "/" or request.path.startswith("/page"):
        ip = request.remote_addr or "Unknown"

        with get_db() as db:
            db.execute(
                "INSERT INTO visits (ip, path, visited_at) VALUES (?, ?, ?)",
                (ip, request.path, datetime.now(timezone.utc).isoformat())
            )

@app.route("/")
def dashboard():
    return render_template_string(HTML)

@app.route("/api/dashboard")
def dashboard_api():
    host = get_host()
    containers = get_containers()

    return jsonify({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "host": host,
        "docker": get_docker_info(),
        "containers": containers,
        "nginx": nginx_status(),
        "visitors": visitor_data(),
        "application": {
            "hostname": socket.gethostname(),
            "ip": container_ip(),
            "uptime_seconds": round(time.time() - START_TIME)
        }
    })

@app.route("/health")
def health():
    return jsonify({"status": "healthy"})

HTML = r"""
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Docker Monitoring Dashboard</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#101827;color:#e5edf7;
font-family:Arial,sans-serif;padding:24px}
h1{margin-bottom:5px}
.sub{color:#9baec5}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));
gap:15px;margin:20px 0}
.card{background:#1c293b;padding:20px;border-radius:12px;
border:1px solid #34445b;overflow-wrap:anywhere}
.card h3{font-size:14px;color:#a7b9d0;margin-top:0}
.value{font-size:25px;font-weight:bold;margin:10px 0}
small{color:#a7b9d0}
.section{margin-top:30px}
table{width:100%;border-collapse:collapse;background:#1c293b;
border-radius:10px;overflow:hidden}
th,td{padding:12px;text-align:left;border-bottom:1px solid #34445b;
font-size:13px}
th{color:#9db2cc}
.ok{color:#4ade80}.bad{color:#fb7185}
.bar{height:9px;background:#35445b;border-radius:10px;margin-top:8px}
.fill{height:100%;background:#38bdf8;border-radius:10px}
.tablewrap{overflow-x:auto}
.footer{margin-top:30px;color:#8fa2bc;font-size:12px}
</style>
</head>
<body>
<h1>🐳 Docker Monitoring Dashboard</h1>
<div class="sub">Host, container and web traffic monitoring</div>
<div class="sub" id="updated">Loading...</div>

<h2 class="section">Docker Host</h2>
<div class="grid">
<div class="card"><h3>HOSTNAME</h3><div class="value" id="hostname">-</div><small id="hostip"></small></div>
<div class="card"><h3>CPU USAGE</h3><div class="value" id="cpu">-</div><div class="bar"><div class="fill" id="cpubar"></div></div></div>
<div class="card"><h3>MEMORY USAGE</h3><div class="value" id="memory">-</div><div class="bar"><div class="fill" id="membar"></div></div></div>
<div class="card"><h3>DISK USAGE</h3><div class="value" id="disk">-</div><div class="bar"><div class="fill" id="diskbar"></div></div></div>
<div class="card"><h3>LOAD AVERAGE</h3><div class="value" id="load">-</div><small>1 / 5 / 15 minutes</small></div>
<div class="card"><h3>HOST UPTIME</h3><div class="value" id="hostuptime">-</div></div>
</div>

<h2 class="section">Docker Engine</h2>
<div class="grid">
<div class="card"><h3>ENGINE STATUS</h3><div class="value" id="engine">-</div></div>
<div class="card"><h3>DOCKER VERSION</h3><div class="value" id="version">-</div></div>
<div class="card"><h3>RUNNING CONTAINERS</h3><div class="value" id="running">-</div></div>
<div class="card"><h3>STOPPED CONTAINERS</h3><div class="value" id="stopped">-</div></div>
<div class="card"><h3>TOTAL IMAGES</h3><div class="value" id="images">-</div></div>
</div>

<h2 class="section">Web Application</h2>
<div class="grid">
<div class="card"><h3>CONTAINER HOSTNAME / IP</h3><div class="value" id="apphost">-</div><small id="appip"></small></div>
<div class="card"><h3>NGINX STATUS</h3><div class="value" id="nginx">-</div><small id="nginxdetails"></small></div>
<div class="card"><h3>APPLICATION UPTIME</h3><div class="value" id="appuptime">-</div></div>
</div>

<h2 class="section">Visitor Statistics</h2>
<div class="grid">
<div class="card"><h3>TOTAL HITS</h3><div class="value" id="hits">-</div></div>
<div class="card"><h3>UNIQUE VISITOR IPs</h3><div class="value" id="unique">-</div></div>
</div>

<h2 class="section">Container Details</h2>
<div class="tablewrap">
<table>
<thead><tr><th>Name</th><th>Container ID</th><th>Image</th>
<th>Status</th><th>IP</th><th>CPU %</th><th>Memory</th>
<th>Network RX/TX MB</th></tr></thead>
<tbody id="containers"></tbody>
</table>
</div>

<h2 class="section">Recent Visitors</h2>
<div class="tablewrap">
<table><thead><tr><th>Visitor IP</th><th>Path</th><th>Time (UTC)</th></tr></thead>
<tbody id="visitors"></tbody></table>
</div>
<div class="footer">Refresh interval: 5 seconds · Monitoring dashboard</div>

<script>
const el=id=>document.getElementById(id);
const val=(id,v)=>el(id).textContent=v??"-";
const bar=(id,v)=>el(id).style.width=Math.min(100,Math.max(0,v||0))+"%";
const uptime=s=>Math.floor(s/86400)+"d "+Math.floor(s%86400/3600)+"h";

async function refresh(){
 try{
 const r=await fetch("/api/dashboard");
 if(!r.ok)throw Error("API error");
 const d=await r.json(),h=d.host,x=d.docker,v=d.visitors;

 val("updated","Last updated: "+new Date(d.timestamp).toLocaleString());
 val("hostname",h.hostname);val("hostip","IP: "+h.ip);
 val("cpu",h.cpu_percent+"%");bar("cpubar",h.cpu_percent);
 val("memory",h.memory_used_gb+" / "+h.memory_total_gb+" GB ("+h.memory_percent+"%)");
 bar("membar",h.memory_percent);
 val("disk",h.disk_used_gb+" / "+h.disk_total_gb+" GB ("+h.disk_percent+"%)");
 bar("diskbar",h.disk_percent);
 val("load",h.load_average?.map(x=>x.toFixed(2)).join(" / "));
 val("hostuptime",h.uptime_hours+" hours");
 val("engine",x.status);val("version",x.version);
 val("running",x.running);val("stopped",x.stopped);val("images",x.images);
 val("apphost",d.application.hostname);val("appip","IP: "+d.application.ip);
 val("appuptime",uptime(d.application.uptime_seconds));
 val("nginx",d.nginx.status);val("nginxdetails",d.nginx.details);
 val("hits",v.total_hits);val("unique",v.unique_visitors);

 el("containers").innerHTML=d.containers.map(c=>{
 const s=c.stats||{};
 return `<tr><td>${c.name}</td><td>${c.id}</td><td>${c.image}</td>
 <td class="${c.state==="running"?"ok":"bad"}">${c.status}</td>
 <td>${c.ip}</td><td>${s.cpu_percent??"-"}</td>
 <td>${s.memory_usage_mb??"-"} / ${s.memory_limit_mb??"-"} MB</td>
 <td>${s.network_rx_mb??"-"} / ${s.network_tx_mb??"-"}</td></tr>`;
 }).join("")||"<tr><td colspan='8'>No containers found</td></tr>";

 el("visitors").innerHTML=v.recent.map(a=>
 `<tr><td>${a.ip}</td><td>${a.path}</td><td>${a.time}</td></tr>`
 ).join("");
 }catch(e){val("updated","Monitoring API unavailable: "+e.message)}
}
refresh();
setInterval(refresh,5000);
</script>
</body>
</html>
"""

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
