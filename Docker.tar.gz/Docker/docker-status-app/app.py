import socket
from flask import Flask, request, render_template_string

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docker Node Status</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #0f172a;
            color: #f8fafc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .card {
            background-color: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 2rem;
            width: 100%;
            max-width: 440px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.4);
        }
        h2 {
            margin-top: 0;
            font-size: 1.25rem;
            border-bottom: 1px solid #334155;
            padding-bottom: 0.75rem;
            color: #e2e8f0;
        }
        .row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.85rem 0;
            border-bottom: 1px solid #334155;
        }
        .row:last-child { border-bottom: none; }
        .label { color: #94a3b8; font-size: 0.95rem; }
        .value {
            font-family: monospace;
            font-size: 1rem;
            font-weight: 600;
            color: #38bdf8;
        }
        .badge {
            background-color: #064e3b;
            color: #34d399;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.85rem;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>Container & Network Status</h2>
        <div class="row">
            <span class="label">Server Status</span>
            <span class="badge">● {{ status }}</span>
        </div>
        <div class="row">
            <span class="label">Container Hostname</span>
            <span class="value">{{ hostname }}</span>
        </div>
        <div class="row">
            <span class="label">Container IP</span>
            <span class="value">{{ server_ip }}</span>
        </div>
        <div class="row">
            <span class="label">Visitor IP (You)</span>
            <span class="value">{{ visitor_ip }}</span>
        </div>
    </div>
</body>
</html>
"""

def get_server_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()
    except Exception:
        return socket.gethostbyname(socket.gethostname())

def get_client_ip():
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",").strip()
    return request.remote_addr

@app.route("/")
def index():
    return render_template_string(
        HTML_TEMPLATE,
        status="ONLINE",
        hostname=socket.gethostname(),
        server_ip=get_server_ip(),
        visitor_ip=get_client_ip()
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
