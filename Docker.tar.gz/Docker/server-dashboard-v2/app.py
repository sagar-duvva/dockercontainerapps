
import os
import socket
import platform
import datetime
import time
import psutil
import requests

from flask import Flask, render_template, jsonify, request

app = Flask(__name__)

# Host filesystem mounts configured in Docker Compose
HOST_PROC = "/host/proc"
HOST_ROOT = "/host/root"

# Configure psutil to read host CPU and memory information
psutil.PROCFS_PATH = HOST_PROC

NGINX_STATUS_URL = os.getenv(
    "NGINX_STATUS_URL",
    "http://host.docker.internal:8081/nginx_status"
)

NGINX_HEALTH_URL = os.getenv(
    "NGINX_HEALTH_URL",
    "http://host.docker.internal:8081/"
)

HOST_LAN_IP = os.getenv("HOST_LAN_IP", "Not configured")


def get_container_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "Unavailable"


def get_host_gateway():
    try:
        result = socket.gethostbyname("host.docker.internal")
        return result
    except Exception:
        return "Unavailable"


def get_host_cpu():
    try:
        return {
            "usage": psutil.cpu_percent(interval=0.3),
            "cores": psutil.cpu_count(logical=True) or 0
        }
    except Exception:
        return {"usage": 0, "cores": 0}


def get_host_memory():
    try:
        mem = psutil.virtual_memory()

        return {
            "total": round(mem.total / (1024 ** 3), 2),
            "used": round(mem.used / (1024 ** 3), 2),
            "free": round(mem.available / (1024 ** 3), 2),
            "percent": mem.percent
        }
    except Exception:
        return {
            "total": 0,
            "used": 0,
            "free": 0,
            "percent": 0
        }


def get_host_disk():
    try:
        disk = psutil.disk_usage(HOST_ROOT)

        return {
            "total": round(disk.total / (1024 ** 3), 2),
            "used": round(disk.used / (1024 ** 3), 2),
            "free": round(disk.free / (1024 ** 3), 2),
            "percent": disk.percent
        }
    except Exception:
        return {
            "total": 0,
            "used": 0,
            "free": 0,
            "percent": 0
        }


def get_uptime():
    try:
        with open(f"{HOST_PROC}/uptime") as f:
            seconds = int(float(f.read().split()[0]))

        days, remainder = divmod(seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, _ = divmod(remainder, 60)

        return f"{days}d {hours}h {minutes}m"
    except Exception:
        return "Unavailable"


def get_nginx_status():
    result = {
        "status": "Unknown",
        "active_connections": None,
        "reading": None,
        "writing": None,
        "waiting": None
    }

    try:
        response = requests.get(
            NGINX_HEALTH_URL,
            timeout=2
        )
        result["status"] = (
            "Running" if response.status_code == 200
            else "Unhealthy"
        )

    except requests.RequestException:
        result["status"] = "Unreachable"

    try:
        response = requests.get(
            NGINX_STATUS_URL,
            timeout=2
        )
        response.raise_for_status()

        lines = response.text.strip().splitlines()

        if len(lines) >= 3:
            result["active_connections"] = int(
                lines[0].split(":")[1].strip()
            )

            values = lines[2].split()

            result["reading"] = int(values[0])
            result["writing"] = int(values[1])
            result["waiting"] = int(values[2])

    except (requests.RequestException, ValueError, IndexError):
        pass

    return result


def get_server_info():
    return {
        "hostname": socket.gethostname(),
        "container_ip": get_container_ip(),
        "host_gateway": get_host_gateway(),
        "host_lan_ip": HOST_LAN_IP,
        "platform": platform.system(),
        "os": platform.release(),
        "cpu": get_host_cpu(),
        "memory": get_host_memory(),
        "disk": get_host_disk(),
        "uptime": get_uptime(),
        "nginx": get_nginx_status(),
        "time": datetime.datetime.now().astimezone().strftime(
            "%Y-%m-%d %H:%M:%S %Z"
        )
    }


@app.route("/")
def dashboard():
    return render_template(
        "dashboard.html",
        visitor_ip=request.remote_addr or "Unknown",
        user_agent=request.headers.get("User-Agent", "Unknown")
    )


@app.route("/api/status")
def api_status():
    return jsonify({
        "application": "Server Dashboard",
        "status": "Running",
        "server": get_server_info(),
        "visitor": {
            "ip": request.remote_addr or "Unknown",
            "user_agent": request.headers.get("User-Agent", "Unknown")
        }
    })


@app.route("/health")
def health():
    return jsonify({"status": "healthy"}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
