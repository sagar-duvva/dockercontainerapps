
from flask import Flask, request, jsonify, render_template_string
import socket
import datetime
import os
import platform

app = Flask(__name__)

def get_server_ip():
    """Detect the container's primary network IP."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "Unavailable"

def get_server_info():
    return {
        "status": "Running",
        "hostname": socket.gethostname(),
        "ip": get_server_ip(),
        "platform": platform.system(),
        "time": datetime.datetime.now().astimezone().isoformat()
    }

@app.route("/")
def home():
    server = get_server_info()

    # Direct client address; do not trust arbitrary forwarded headers.
    visitor_ip = request.remote_addr or "Unknown"
    user_agent = request.headers.get("User-Agent", "Unknown")

    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Server Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="refresh" content="10">
        <style>
            * { box-sizing: border-box; }
            body {
                margin: 0;
                padding: 30px 16px;
                font-family: Arial, sans-serif;
                background: #101827;
                color: white;
            }
            .container {
                max-width: 850px;
                margin: auto;
            }
            h1 { text-align: center; }
            .subtitle {
                text-align: center;
                color: #9ca3af;
                margin-bottom: 30px;
            }
            .grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
                gap: 16px;
            }
            .card {
                background: #1e293b;
                padding: 22px;
                border-radius: 12px;
                border: 1px solid #334155;
                overflow-wrap: anywhere;
            }
            .card h3 {
                color: #94a3b8;
                margin-top: 0;
                font-size: 14px;
            }
            .value {
                font-size: 21px;
                font-weight: bold;
                color: #38bdf8;
            }
            .status { color: #4ade80; }
            .footer {
                text-align: center;
                color: #94a3b8;
                margin-top: 30px;
                font-size: 13px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Server Information Dashboard</h1>
            <div class="subtitle">Docker Server Monitoring</div>

            <div class="grid">
                <div class="card">
                    <h3>SERVER STATUS</h3>
                    <div class="value status">● {{ server.status }}</div>
                </div>

                <div class="card">
                    <h3>SERVER HOSTNAME</h3>
                    <div class="value">{{ server.hostname }}</div>
                </div>

                <div class="card">
                    <h3>SERVER IP ADDRESS</h3>
                    <div class="value">{{ server.ip }}</div>
                </div>

                <div class="card">
                    <h3>SERVER PLATFORM</h3>
                    <div class="value">{{ server.platform }}</div>
                </div>

                <div class="card">
                    <h3>VISITOR IP ADDRESS</h3>
                    <div class="value">{{ visitor_ip }}</div>
                </div>

                <div class="card">
                    <h3>SERVER TIME</h3>
                    <div class="value">{{ server.time }}</div>
                </div>

                <div class="card" style="grid-column: 1 / -1">
                    <h3>VISITOR BROWSER INFORMATION</h3>
                    <div style="overflow-wrap:anywhere">
                        {{ user_agent }}
                    </div>
                </div>
            </div>

            <div class="footer">
                Automatically refreshes every 10 seconds
                <br><br>
                Powered by Python Flask & Docker
            </div>
        </div>
    </body>
    </html>
    """, server=server, visitor_ip=visitor_ip, user_agent=user_agent)


@app.route("/api/status")
def api_status():
    return jsonify({
        "server": get_server_info(),
        "visitor": {
            "ip": request.remote_addr or "Unknown",
            "user_agent": request.headers.get("User-Agent", "Unknown")
        }
    })


@app.route("/health")
def health():
    return jsonify({"status": "healthy"}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
